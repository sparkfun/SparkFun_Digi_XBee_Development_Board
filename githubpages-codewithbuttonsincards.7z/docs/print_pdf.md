---
icon: fontawesome/regular/file-pdf
---


# Download Hookup Guide
[Download :fontawesome-regular-file-pdf:](../assets/SparkFun_XBee_Smart_Modem-hookup-guide.pdf)